<?php     


/*
 * examples/mysql/loaddata.php
 * 
 * This file is part of EditableGrid.
 * http://editablegrid.net
 *
 * Copyright (c) 2011 Webismymind SPRL
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://editablegrid.net/license
 */
                              


/**
 * This script loads data from the database and returns it to the js
 *
 */
       
require_once('config.php');      
require_once('EditableGrid.php');            

/**
 * fetch_pairs is a simple method that transforms a mysqli_result object in an array.
 * It will be used to generate possible values for some columns.
*/
function fetch_pairs($mysqli,$query){
	if (!($res = $mysqli->query($query)))return FALSE;
	$rows = array();
	while ($row = $res->fetch_assoc()) {
		$first = true;
		$key = $value = null;
		foreach ($row as $val) {
			if ($first) { $key = $val; $first = false; }
			else { $value = $val; break; } 
		}
		$rows[$key] = $value;
	}
	return $rows;
}


// Database connection
$mysqli = mysqli_init();
$mysqli->options(MYSQLI_OPT_CONNECT_TIMEOUT, 5);
$mysqli->real_connect($config['db_host'],$config['db_user'],$config['db_password'],$config['db_name']); 
                    
// create a new EditableGrid object
$grid = new EditableGrid();

/* 
*  Add columns. The first argument of addColumn is the name of the field in the databse. 
*  The second argument is the label that will be displayed in the header
*/
$grid->addColumn('id', 'ID', 'integer', NULL, false); 
$grid->addColumn('tblName', 'Name', 'string');
$grid->addColumn('numyears', 'numyears', 'string');
$grid->addColumn('UCODE', 'Unit Code', 'string');
$grid->addColumn('yrservice', 'Last UPCAT year', 'string');
$grid->addColumn('TCTRCODE', 'Test Center Code', 'string');
$grid->addColumn('testcenter', 'Testing Center', 'string');
$grid->addColumn('ASSG', 'Assignment', 'string',fetch_pairs($mysqli,'SELECT id,Des_Code FROM Rates WHERE Des_Code in ("RE", "RA", "P" ,"PA" ,"A" ,"EP" ,"HSE" ,"E")'),true );
$grid->addColumn('invite', 'Invitation', 'boolean');
$grid->addColumn('firsttimer', 'First time', 'boolean');


$mydb_tablename = (isset($_GET['db_tablename'])) ? stripslashes($_GET['db_tablename']) : 'Invites';
                                                                       
$result = $mysqli->query('SELECT * FROM '.$mydb_tablename );
$mysqli->close();

// send data to the browser
$grid->renderJSON($result);

